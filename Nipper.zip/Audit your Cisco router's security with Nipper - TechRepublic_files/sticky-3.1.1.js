/*!
Waypoints Sticky Element Shortcut - 3.1.1
Copyright © 2011-2015 Caleb Troughton
Licensed under the MIT license.
https://github.com/imakewebthings/waypoints/blog/master/licenses.txt
*/

define(["jquery","version!libs/waypoints/jquery.waypoints"],function(){"use strict";function t(n){this.options=$.extend({},e.defaults,t.defaults,n),this.element=this.options.element,this.$element=$(this.element),this.createWrapper(),this.createWaypoint()}var e=window.Waypoint;t.prototype.createWaypoint=function(){var t=this.options.handler;this.waypoint=new e($.extend({},this.options,{element:this.wrapper,handler:$.proxy(function(e){var n=this.options.direction.indexOf(e)>-1,r=n?this.$element.outerHeight(!0):"";this.$wrapper.height(r),this.$element.toggleClass(this.options.stuckClass,n),t&&t.call(this,e)},this)}))},t.prototype.createWrapper=function(){this.$element.wrap(this.options.wrapper),this.$wrapper=this.$element.parent(),this.wrapper=this.$wrapper[0]},t.prototype.destroy=function(){this.$element.parent()[0]===this.wrapper&&(this.waypoint.destroy(),this.$element.removeClass(this.options.stuckClass).unwrap())},t.defaults={wrapper:'<div class="sticky-wrapper" />',stuckClass:"stuck",direction:"down right"},e.Sticky=t})