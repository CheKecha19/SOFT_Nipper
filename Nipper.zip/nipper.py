import os
import subprocess
import pandas as pd
from bs4 import BeautifulSoup

# Пути к папкам
nipper_path = r"C:\сканеры\github\Nipper"
input_folder = os.path.join(nipper_path, "configs")
output_folder = os.path.join(nipper_path, "results")

# Функция для выполнения команды Nipper и преобразования файлов .cfg в .txt
def run_nipper_and_convert():
    for file_name in os.listdir(input_folder):
        if file_name.endswith(".cfg"):
            txt_file = file_name.replace(".cfg", ".txt")
            txt_path = os.path.join(input_folder, txt_file)
            
            # Запуск Nipper
            command = [
                os.path.join(nipper_path, "nipper.exe"),
                "--input", os.path.join(input_folder, file_name),
                "--output", txt_path,
                "--css"
            ]
            print(f"Выполнение команды: {' '.join(command)}")
            subprocess.run(command, check=True)

# Функция для извлечения раздела "Security audit" из HTML-файлов
def extract_security_audit(html_file):
    with open(html_file, "r", encoding="utf-8") as file:
        content = file.read()

    soup = BeautifulSoup(content, 'html.parser')
    
    # Ищем заголовок "Security audit"
    security_audit_section = soup.find('h2', string=lambda s: 'Security Audit' in s)

    if not security_audit_section:
        print(f"Раздел 'Security Audit' не найден в файле {html_file}")
        return None
    
    vulnerabilities = []
    
    # Идем по контенту до следующего заголовка h2
    current_tag = security_audit_section.find_next_sibling()
    
    while current_tag and current_tag.name != "h2":  # Проходим до следующего заголовка h2
        if current_tag.name == "h3":  # Название уязвимости
            vuln_title = current_tag.get_text()
            recommendation = ""

            # Ищем блок с рекомендацией
            next_tag = current_tag.find_next_sibling()
            while next_tag and next_tag.name != "h3" and next_tag.name != "h2":
                if "recommendation" in next_tag.get_text().lower():
                    recommendation = next_tag.get_text()
                    break
                next_tag = next_tag.find_next_sibling()
            
            vulnerabilities.append({
                "Title": vuln_title.strip(),
                "Recommendation": recommendation.strip()
            })
        
        current_tag = current_tag.find_next_sibling()

    return vulnerabilities

# Функция для создания Excel файла с итогами
def create_excel_report(vulnerability_list):
    # Уникальные уязвимости
    unique_vulnerabilities = {vuln['Title'] for entry in vulnerability_list for vuln in entry['Vulnerabilities']}
    unique_vulnerabilities = list(unique_vulnerabilities)

    # Создаем таблицу
    columns = ["IP Address"] + unique_vulnerabilities + [f"Recommendation {v}" for v in unique_vulnerabilities]
    rows = []

    for entry in vulnerability_list:
        row = {"IP Address": entry["IP Address"]}
        
        for vuln in unique_vulnerabilities:
            found_vuln = next((v for v in entry["Vulnerabilities"] if v['Title'] == vuln), None)
            if found_vuln:
                row[vuln] = 1
                row[f"Recommendation {vuln}"] = found_vuln['Recommendation']
            else:
                row[vuln] = 0
                row[f"Recommendation {vuln}"] = ""
        
        rows.append(row)

    df = pd.DataFrame(rows, columns=columns)

    # Сохранение в Excel
    output_file = os.path.join(output_folder, "security_audit_results.xlsx")
    df.to_excel(output_file, index=False)
    print(f"Результаты сохранены в {output_file}")

# Основная логика
def main():
    # Выполняем Nipper и конвертируем файлы .cfg в .txt
    run_nipper_and_convert()

    # Собираем данные по уязвимостям из всех .html файлов в $outputFolder
    vulnerability_list = []
    for file_name in os.listdir(output_folder):
        if file_name.endswith(".html"):
            ip_address = file_name.split("_")[0]  # Получаем IP из названия файла
            html_path = os.path.join(output_folder, file_name)
            
            security_audit = extract_security_audit(html_path)
            if security_audit:
                vulnerability_list.append({
                    "IP Address": ip_address,
                    "Vulnerabilities": security_audit
                })

    # Создаем отчет в Excel
    create_excel_report(vulnerability_list)

if __name__ == "__main__":
    main()
